# NovaSignal — Il simbolo conduce lo spazio

Revisione del 15 ottobre 2026. Sito React/TanStack con film Higgsfield e logo reale Three.js.

## Modifiche
- Pagina, scroll e pose: app/src/components/nova/DirectedSite.tsx
- Logo originale, materiali, riflessi, split: app/src/components/nova/BrandWorld.tsx
- Pagine ORA e FORMA: app/src/components/nova/ConceptPages.tsx
- Layout: directed.css e concept-pages.css nella stessa cartella
- Contenuti verificati: app/src/content.ts
- Asset correnti: app/public/assets/brand-*
- Provenienza delle generazioni: app/production-record.json

NovaSite.tsx è il punto di ingresso e importa DirectedSite. Gli asset e i componenti della versione precedente restano nel progetto per tracciabilità. Il vecchio novasignal.glb rappresenta la precedente scultura N: il modello attuale è la geometria modificabile in BrandWorld.tsx.

## Avvio
Da app/: bun install, bun run dev.
Verifiche: bun run typecheck, bun run build.
Anteprima statica: bunx vite build --config vite.preview.config.ts.

## Esperienza
Il primo piano cinematografico si raccorda al logo in tempo reale. Lo scroll governa posizione, scala, rotazione e apertura del simbolo. Le pagine HTML emergono in prospettiva. Il modulo prepara una bozza WhatsApp; l'invio resta al visitatore. ORA e FORMA sono concept dimostrativi, dichiarati nella pagina.

## Stato
Questa è la copia più aggiornata del progetto. La versione ospitata su Higgsfield non è sincronizzata a causa di un blocco del servizio. Il dominio novasignal.it non è stato modificato. Il sito di anteprima usa noindex.
