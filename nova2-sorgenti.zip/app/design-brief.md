# NovaSignal: il segnale prende forma
Design read: studio italiano di siti, applicazioni e identità per aziende che vogliono una presenza riconoscibile.
Concept spine: un segnale fisico, composto da tre barre metalliche, diventa un sistema digitale.
Delivery tier: spectacle
Animation mode: animated-website
User instruction: cinematic motion scroll and actual browser-rendered 3D, autonomous production.
Journey shape: single-shot, one transformation of one subject; desktop and portrait versions.
Journey: establishing sculpture; precise exploded surfaces; digital planes; resolved signal.
World grammar: deep wine #24131b, pearl #f2efef, raspberry #df667c, silver, smoked glass.
Lighting: broad neutral white softboxes, controlled raspberry reflection, no colored glow.
Camera: slow continuous three-quarter orbit and modest dolly; constant exposure, clean frames.
Mobile framing: dedicated 9:16 film; subject in upper center, copy in lower third.
Delivery budget: desktop <=20 MiB, mobile <=10 MiB; generated originals preserved outside Git.
Locked palette: #24131b base; #321b26 panels; #f2efef ink; #c6b5bc secondary; #df667c accent.
Palette defense: a warm photographic studio complements precision metal, separate from neon tech cliches.
Locked type: Satoshi variable display and body; JetBrains Mono small functional details.
Theme paradigm: Bold Studio Solid.
Background character: full-bleed cinema plus solid studio fields.
Typography character: refined grotesk.
Hero architecture: image-first with wide bottom-left headline and open central silhouette.
Section system: gallery-led cadence.
Signature components: hover accordion slices, layered image frames, off-grid editorial, vertical rhythm lines.
Second-read moment: macro crop carrying the brand reflection.
Corner language: square editorial geometry; circular contact and object controls only.
Section plan:
1. Cinema: single-shot film, headline and primary contact link, skip action.
2. Services: large numbered horizontal accordion rows and single shared photographic detail.
3. Concepts: two large staggered image-led project entries, each opens an accessible project dialog.
4. Signal lab: real Three.js model, camera orbit and material switching, explanatory text.
5. Method: an editorial four-step path with a shared line responding to scroll.
6. Contact: oversized invitation and a working WhatsApp brief builder plus mailto alternative.
Asset plan: storyboard, five section boards, hero keyframe landscape and portrait, two films, two concept images, macro plate, icon sheet, OG.
Existing logo: inspect live site and preserve its source mark if present; use wordmark as found.
CTA inventory: nav text with sliding rule; hero framed arrow; project whole-image reveal; contact full-width text link; form solid action.
Business facts source: current www.novasignal.it read 2026-10-15; services websites, web apps, mobile apps, branding.
Contact source: studio@novasignal.it; WhatsApp +39 320 689 1014; secondary +39 348 184 8483.
Commercial scope: no unsupported prices, metrics, clients, testimonials, claims or deadlines.
Concepts: clearly labeled as creative demonstrations, not commissioned client work.
Functional path: build a WhatsApp draft from user inputs; label that it opens WhatsApp and does not send automatically.
Accessibility: native scroll, anchors, semantic headings, menu focus management, reduced motion, visible fallback.
3D: authored geometry, brushed metal + smoked glass, bounded camera and DPR, render only when visible, pointer and scroll response.
Validation contract: actual browser desktop/mobile/reverse scroll, dialogs, menu, contact link and motion fallbacks.
Preview scope: separate Higgsfield subdomain, no custom domain changes, no community listing.
Sources and code: retain source project, generation job records, original downloadable media.


Existing brand exception: preserve the original orange/teal lightning mark exactly; the silver N is campaign art, not a replacement logo.
