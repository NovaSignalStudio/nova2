import React from "react";
import {createRoot} from "react-dom/client";
import NovaSite from "../src/components/nova/NovaSite";
import "../src/styles.css";
createRoot(document.getElementById("root")!).render(<NovaSite/>);
