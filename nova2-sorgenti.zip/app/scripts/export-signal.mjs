import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {GLTFExporter} from 'three/examples/jsm/exporters/GLTFExporter.js';
import {writeFileSync,mkdirSync} from 'node:fs';
globalThis.FileReader=class {readAsArrayBuffer(blob){blob.arrayBuffer().then(data=>{this.result=data;this.onloadend?.()})}readAsDataURL(blob){blob.arrayBuffer().then(data=>{this.result='data:'+blob.type+';base64,'+Buffer.from(data).toString('base64');this.onloadend?.()})}};
const group=new THREE.Group();group.name='NovaSignal sculpture';
const silver=new THREE.MeshPhysicalMaterial({name:'Polished silver',color:0xe2d9dc,metalness:1,roughness:.19,clearcoat:.8});
const inset=new THREE.MeshPhysicalMaterial({name:'Raspberry glass insert',color:0xb52a51,metalness:.5,roughness:.2,clearcoat:1});
const glass=new THREE.MeshPhysicalMaterial({name:'Smoked glass layers',color:0xe8b0bf,metalness:.12,roughness:.1,transmission:.88,thickness:.45,ior:1.5,transparent:true,opacity:.95});
for(let i=0;i<3;i++){const bar=new THREE.Group();bar.name=['Left upright','Diagonal bridge','Right upright'][i];bar.position.x=(i-1)*.94;if(i===1)bar.rotation.z=.62;const h=i===1?3.15:2.8;bar.add(new THREE.Mesh(new RoundedBoxGeometry(.6,h,.58,4,.055),silver));const line=new THREE.Mesh(new RoundedBoxGeometry(.055,h-.21,.035,4,.012),inset);line.position.set(.19,0,.305);bar.add(line);group.add(bar);const layer=new THREE.Mesh(new RoundedBoxGeometry(.68,2.95,.07,4,.025),glass);layer.name='Glass layer '+(i+1);layer.position.set((i-1)*.94,0,-.4);if(i===1)layer.rotation.z=.62;group.add(layer)}
const result=await new GLTFExporter().parseAsync(group,{binary:true});
mkdirSync('public/assets/models',{recursive:true});writeFileSync('public/assets/models/novasignal.glb',Buffer.from(result));console.log('Exported editable glTF model:',result.byteLength,'bytes');
