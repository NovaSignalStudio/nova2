import {useEffect,useId,useRef,useState} from "react";
import * as THREE from "three";

export type BrandPose={x:number;y:number;scale:number;rx:number;ry:number;rz:number;split:number;opacity:number};
const DEFAULT_POSE:BrandPose={x:.43,y:0,scale:1,rx:.10,ry:-.25,rz:0,split:0,opacity:0};
const POSE_KEYS=Object.keys(DEFAULT_POSE) as (keyof BrandPose)[];
const OUTLINE:[number,number][]=[[21.5,0],[21.5,19.5],[31.5,19.5],[31.5,29],[10,48.5],[10,28.5],[.5,28.5],[.5,18.5]];
const INSERTS:[number,number][][]=[[[.5,18.5],[9.5,18.5],[9.5,28.5],[.5,28.5]],[[22,19.5],[31.5,19.5],[31.5,29],[22,29]]];
const UNIT=3/48.5;


function clipAtSeam(points:[number,number][],upper:boolean):[number,number][]{
 // The seam joins the two inner corners; each original chrome inlay stays whole.
 const side=(p:[number,number])=>p[1]-28.5+(p[0]-10)*9/11.5;
 const result:[number,number][]=[];
 const push=(p:[number,number])=>{const last=result[result.length-1];if(!last||Math.abs(last[0]-p[0])+Math.abs(last[1]-p[1])>1e-7)result.push(p)};
 for(let i=0;i<points.length;i++){
  const a=points[i],b=points[(i+1)%points.length],da=side(a),db=side(b);
  const insideA=upper?da<=0:da>=0,insideB=upper?db<=0:db>=0;
  if(insideA)push(a);
  if(insideA!==insideB){const t=da/(da-db);push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t])}
 }
 if(result.length>1){const a=result[0],b=result[result.length-1];if(Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])<1e-7)result.pop()}
 return result;
}

/** One SVG silhouette, one scene, one pose owner: the page's nova:pose event. */
export default function BrandWorld({className=""}:{className?:string}){
 const host=useRef<HTMLDivElement>(null),fallback=useRef<HTMLDivElement>(null);
 const target=useRef<BrandPose>({...DEFAULT_POSE});
 const [ready,setReady]=useState(false),[reduced,setReduced]=useState(false);
 const id=useId().replaceAll(":","");
 useEffect(()=>{
  const media=window.matchMedia("(prefers-reduced-motion: reduce)");
  const sync=()=>setReduced(media.matches);sync();media.addEventListener("change",sync);
  return()=>media.removeEventListener("change",sync);
 },[]);
 useEffect(()=>{
  const el=host.current;if(!el)return;
  const media=window.matchMedia("(prefers-reduced-motion: reduce)");
  let alive=true,frame=0,lastTime=0,firstFrame=true,failed=false;
  const current:BrandPose={...target.current};
  const pointerTarget={x:0,y:0},pointerCurrent={x:0,y:0};
  let pointerEnabled=window.matchMedia("(hover: hover) and (pointer: fine)").matches&&window.innerWidth>700;
  let viewWidth=5,viewHeight=5;
  const posterPose=(p:BrandPose)=>{
   const node=fallback.current;if(!node)return;
   // Reduced motion keeps the same subject in a stable composition.
   const stable=media.matches?DEFAULT_POSE:p;
   node.style.left=(50+stable.x*50)+"%";node.style.top=(50-stable.y*50)+"%";
   node.style.height=(60*stable.scale)+"%";node.style.opacity=String(p.opacity);
   node.style.transform="translate(-50%,-50%) rotate("+stable.rz+"rad)";
  };
  posterPose(current);
  let renderer:THREE.WebGLRenderer|null=null;
  let renderScene:(()=>void)|undefined;
  const schedule=()=>{if(alive&&!failed&&!document.hidden&&!frame&&renderer)frame=requestAnimationFrame(tick)};
  const onPose=(event:Event)=>{
   const detail=(event as CustomEvent<Partial<BrandPose>>).detail;if(!detail)return;
   let changed=false;
   for(const key of POSE_KEYS){const value=detail[key];if(typeof value==="number"&&Number.isFinite(value)){if(Math.abs(target.current[key]-value)>.00005)changed=true;target.current[key]=value}}
   target.current.x=THREE.MathUtils.clamp(target.current.x,-1,1);
   target.current.y=THREE.MathUtils.clamp(target.current.y,-1,1);
   target.current.scale=THREE.MathUtils.clamp(target.current.scale,0,5);
   target.current.split=THREE.MathUtils.clamp(target.current.split,0,1);
   target.current.opacity=THREE.MathUtils.clamp(target.current.opacity,0,1);
   if(!renderer||media.matches||failed)posterPose(target.current);
   if(changed)schedule();
  };
  window.addEventListener("nova:pose",onPose);
  setReady(false);
  if(media.matches){
   return()=>{alive=false;window.removeEventListener("nova:pose",onPose)};
  }
  try{
   renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:"low-power",premultipliedAlpha:true});
  }catch{
   return()=>{alive=false;window.removeEventListener("nova:pose",onPose)};
  }
  const activeRenderer=renderer;
  activeRenderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.6));
  activeRenderer.setClearColor(0x0d1011,0);
  activeRenderer.outputColorSpace=THREE.SRGBColorSpace;
  activeRenderer.toneMapping=THREE.ACESFilmicToneMapping;
  activeRenderer.toneMappingExposure=1.12;
  const canvas=activeRenderer.domElement;
  Object.assign(canvas.style,{position:"absolute",inset:"0",width:"100%",height:"100%",display:"block",opacity:"0"});
  canvas.setAttribute("aria-hidden","true");el.appendChild(canvas);
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(28.072486935852957,1,.1,40);
  camera.position.set(0,0,10);camera.lookAt(0,0,0);

  // A perspective view and narrow graded softboxes make reflections travel across the metal.
  const studio=new THREE.Scene();studio.background=new THREE.Color(0x454d50);
  const studioMaterials:THREE.Material[]=[],studioGeometry:THREE.BufferGeometry[]=[];
  const stripData=new Uint8Array(256*32*4);
  for(let y=0;y<32;y++)for(let x=0;x<256;x++){
   const u=x/255,v=y/31;
   const bell=Math.exp(-Math.pow((u-.47)/.24,2))*Math.pow(Math.sin(Math.PI*v),.24);
   const i=(y*256+x)*4,n=Math.round(255*(.025+.975*bell));
   stripData[i]=stripData[i+1]=stripData[i+2]=n;stripData[i+3]=255;
  }
  const stripMap=new THREE.DataTexture(stripData,256,32,THREE.RGBAFormat);
  stripMap.magFilter=stripMap.minFilter=THREE.LinearFilter;stripMap.needsUpdate=true;
  const card=(w:number,h:number,x:number,y:number,z:number,intensity:number,color:number)=>{
   const geometry=new THREE.PlaneGeometry(w,h);studioGeometry.push(geometry);
   const material=new THREE.MeshBasicMaterial({map:stripMap,color:new THREE.Color(color).multiplyScalar(intensity),side:THREE.DoubleSide});
   studioMaterials.push(material);const panel=new THREE.Mesh(geometry,material);
   panel.position.set(x,y,z);panel.lookAt(0,0,0);studio.add(panel);
  };
  card(2.8,8,-.6,.4,6.5,3,0xfff3dd);
  card(1.65,7,3.4,-.5,5,3.6,0xe2eff2);
  card(2,7,-4.5,1,3,3.2,0xe6eff0);
  card(5.5,1.4,0,5,2,2.5,0xffe4bd);
  card(1.6,5,3,0,-4,2.2,0xc6e4e8);
  const pmrem=new THREE.PMREMGenerator(activeRenderer);
  const environment=pmrem.fromScene(studio,.035);
  scene.environment=environment.texture;
  studioGeometry.forEach(g=>g.dispose());studioMaterials.forEach(m=>m.dispose());stripMap.dispose();pmrem.dispose();

  // Long, correlated milling strokes survive minification; fine noise only breaks their regularity.
  const grainSize=1024,grainData=new Uint8Array(grainSize*grainSize*4),roughData=new Uint8Array(grainSize*grainSize*4);
  const hash=(n:number)=>{const v=Math.sin(n*127.1+311.7)*43758.5453123;return v-Math.floor(v)};
  const lineNoise=new Float32Array(1800);for(let i=0;i<lineNoise.length;i++)lineNoise[i]=hash(i+17);
  for(let y=0;y<grainSize;y++)for(let x=0;x<grainSize;x++){
   const line=Math.floor(y-x*.32+340),ridge=lineNoise[line];
   const lengthVariation=Math.sin(x*.013+ridge*6.28)*.10;
   const broad=Math.sin(y*.018+x*.005)*.06;
   const fine=hash(x*13+y*19)-.5;
   const height=.5+(ridge-.5)*.33+lengthVariation+broad+fine*.045;
   const rough=.73+(ridge-.5)*.14+lengthVariation*.25+fine*.055;
   const i=(y*grainSize+x)*4;
   grainData[i]=grainData[i+1]=grainData[i+2]=Math.round(THREE.MathUtils.clamp(height,0,1)*255);grainData[i+3]=255;
   roughData[i]=roughData[i+1]=roughData[i+2]=Math.round(THREE.MathUtils.clamp(rough,0,1)*255);roughData[i+3]=255;
  }
  const grain=new THREE.DataTexture(grainData,grainSize,grainSize,THREE.RGBAFormat);
  const roughGrain=new THREE.DataTexture(roughData,grainSize,grainSize,THREE.RGBAFormat);
  [grain,roughGrain].forEach(texture=>{
   texture.wrapS=texture.wrapT=THREE.ClampToEdgeWrapping;
   texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;
   texture.generateMipmaps=true;texture.anisotropy=Math.min(4,activeRenderer.capabilities.getMaxAnisotropy());texture.needsUpdate=true;
  });
  const face=new THREE.MeshPhysicalMaterial({color:0xffffff,vertexColors:true,metalness:1,roughness:.31,roughnessMap:roughGrain,bumpMap:grain,bumpScale:.0018,clearcoat:.08,clearcoatRoughness:.3,anisotropy:.5,anisotropyRotation:-.31,envMapIntensity:1});
  const edge=new THREE.MeshPhysicalMaterial({color:0x879293,metalness:1,roughness:.25,roughnessMap:roughGrain,envMapIntensity:1.1});
  const chrome=new THREE.MeshPhysicalMaterial({color:0xd4dadd,metalness:1,roughness:.30,roughnessMap:roughGrain,bumpMap:grain,bumpScale:.0015,anisotropy:.58,anisotropyRotation:-.31,clearcoat:.08,clearcoatRoughness:.25,envMapIntensity:1.08});
  const materials=[face,edge,chrome];
  for(const material of [face,chrome]){
   material.onBeforeCompile=shader=>{
    shader.vertexShader=shader.vertexShader.replace("#include <beginnormal_vertex>",`#include <beginnormal_vertex>
     if(abs(normal.z)>.985){
      objectNormal=normalize(objectNormal+vec3(position.x*.13,position.y*.045,0.0));
     }`);
   };
   material.customProgramCacheKey=()=> "nova-metal-crown-v1";
  }
  const gradientStops=[
   {p:0,c:new THREE.Color("#f5a329")},{p:.30,c:new THREE.Color("#d58c22")},
   {p:.49,c:new THREE.Color("#9e915b")},{p:.58,c:new THREE.Color("#519f95")},
   {p:.76,c:new THREE.Color("#139cab")},{p:1,c:new THREE.Color("#067e92")}
  ];
  const gradient=(t:number)=>{
   const p=THREE.MathUtils.clamp(t,0,1);let a=gradientStops[0],b=gradientStops[1];
   for(let i=1;i<gradientStops.length;i++){a=gradientStops[i-1];b=gradientStops[i];if(p<=b.p)break}
   return a.c.clone().lerp(b.c,(p-a.p)/(b.p-a.p));
  };
  const geometries:THREE.BufferGeometry[]=[];
  function geometry(points:[number,number][],depth:number,bevel:number){
   const shape=new THREE.Shape();
   points.forEach(([x,y],i)=>{const px=(x-15.75)*UNIT,py=(24.25-y)*UNIT;i===0?shape.moveTo(px,py):shape.lineTo(px,py)});
   shape.closePath();
   const g=new THREE.ExtrudeGeometry(shape,{depth,steps:1,bevelEnabled:true,bevelSegments:4,bevelSize:bevel,bevelThickness:bevel,bevelOffset:-bevel,curveSegments:8});
   g.translate(0,0,-depth/2);
   const positions=g.getAttribute("position"),colors=new Float32Array(positions.count*3),uv=new Float32Array(positions.count*2);
   for(let i=0;i<positions.count;i++){const c=gradient((1.5-positions.getY(i))/3);colors[i*3]=c.r;colors[i*3+1]=c.g;colors[i*3+2]=c.b;uv[i*2]=(positions.getX(i)+.975)/1.95;uv[i*2+1]=(positions.getY(i)+1.5)/3}
   g.setAttribute("uv",new THREE.BufferAttribute(uv,2));g.setAttribute("color",new THREE.BufferAttribute(colors,3));geometries.push(g);return g;
  }
  const sculpture=new THREE.Group();sculpture.name="NovaSignal — original brand mark";scene.add(sculpture);
  function makePart(points:[number,number][],inserts:[number,number][][],name:string){
   const group=new THREE.Group();group.name=name;
   const body=new THREE.Mesh(geometry(points,.40,.032),[face,edge]);body.name="Gradient anodized metal";group.add(body);
   inserts.filter(p=>p.length>=3).forEach((polygon,i)=>{
    const insert=new THREE.Mesh(geometry(polygon,.014,.006),chrome);insert.name="Chrome inlay "+(i+1);insert.position.z=.237;group.add(insert);
    const reverse=insert.clone();reverse.position.z=-.237;group.add(reverse);
   });sculpture.add(group);return group;
  }
  const complete=makePart(OUTLINE,INSERTS,"Complete silhouette");
  const upper=makePart(clipAtSeam(OUTLINE,true),INSERTS.map(p=>clipAtSeam(p,true)),"Upper half");
  const lower=makePart(clipAtSeam(OUTLINE,false),INSERTS.map(p=>clipAtSeam(p,false)),"Lower half");
  upper.visible=lower.visible=false;
  const key=new THREE.DirectionalLight(0xf2eee7,1.8);key.position.set(-3,5,6);scene.add(key);
  const fill=new THREE.DirectionalLight(0xd2e5e5,.65);fill.position.set(4,-2,3);scene.add(fill);
  scene.add(new THREE.AmbientLight(0xadb9bc,.22));

  renderScene=()=>{
   sculpture.position.set(current.x*viewWidth/2,current.y*viewHeight/2,0);
   sculpture.rotation.set(current.rx+pointerCurrent.y,current.ry+pointerCurrent.x,current.rz);
   sculpture.scale.setScalar(current.scale);
   const split=current.split;
   complete.visible=split<.0015;upper.visible=lower.visible=!complete.visible;
   upper.position.set(-split*.47,split*.25,split*.40);
   lower.position.set(split*.47,-split*.25,-split*.40);
   upper.rotation.set(-split*.12,-split*.12,-split*.035);
   lower.rotation.set(split*.12,split*.12,split*.035);
   canvas.style.opacity=String(current.opacity);
   activeRenderer.render(scene,camera);
   if(firstFrame){firstFrame=false;setReady(true)}
   posterPose(current);
  };
  function tick(time:number){
   frame=0;if(!alive||failed||document.hidden)return;
   const dt=lastTime?Math.min((time-lastTime)/1000,.05):1/60;lastTime=time;
   const factor=1-Math.exp(-17*dt);let settled=true;
   for(const key of POSE_KEYS){const delta=target.current[key]-current[key];if(Math.abs(delta)>.00035)settled=false;current[key]+=delta*factor}
   for(const axis of ["x","y"] as const){const delta=pointerTarget[axis]-pointerCurrent[axis];if(Math.abs(delta)>.00008)settled=false;pointerCurrent[axis]+=delta*factor}
   try{renderScene?.()}catch{failed=true;canvas.style.opacity="0";setReady(false);return}
   if(!settled)schedule();
  }
  const resize=()=>{
   const w=el.clientWidth,h=el.clientHeight;if(!w||!h)return;
   viewHeight=5;viewWidth=5*w/h;
   camera.aspect=w/h;camera.updateProjectionMatrix();
   pointerEnabled=window.matchMedia("(hover: hover) and (pointer: fine)").matches&&w>700;if(!pointerEnabled)pointerTarget.x=pointerTarget.y=0;
   activeRenderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.6));activeRenderer.setSize(w,h,false);schedule();
  };
  const ro=new ResizeObserver(resize);ro.observe(el);resize();
  const onVisibility=()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0}else{lastTime=0;schedule()}};
  const onContextLost=(event:Event)=>{event.preventDefault();failed=true;cancelAnimationFrame(frame);frame=0;canvas.style.opacity="0";setReady(false)};
  const onPointer=(event:PointerEvent)=>{
   if(!pointerEnabled||event.pointerType==="touch")return;
   pointerTarget.x=THREE.MathUtils.clamp(event.clientX/window.innerWidth*2-1,-1,1)*.05;
   pointerTarget.y=THREE.MathUtils.clamp(event.clientY/window.innerHeight*2-1,-1,1)*.035;
   schedule();
  };
  const onPointerLeave=()=>{pointerTarget.x=pointerTarget.y=0;schedule()};
  window.addEventListener("pointermove",onPointer,{passive:true});document.addEventListener("pointerleave",onPointerLeave);window.addEventListener("blur",onPointerLeave);
  document.addEventListener("visibilitychange",onVisibility);canvas.addEventListener("webglcontextlost",onContextLost);
  schedule();
  return()=>{
   alive=false;cancelAnimationFrame(frame);ro.disconnect();
   window.removeEventListener("nova:pose",onPose);document.removeEventListener("visibilitychange",onVisibility);
   canvas.removeEventListener("webglcontextlost",onContextLost);
   window.removeEventListener("pointermove",onPointer);document.removeEventListener("pointerleave",onPointerLeave);window.removeEventListener("blur",onPointerLeave);
   geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());grain.dispose();roughGrain.dispose();environment.dispose();
   activeRenderer.dispose();canvas.remove();
  };
 },[reduced]);
 return <div ref={host} className={"brand-world "+className} aria-hidden="true" style={{position:"absolute",inset:0,pointerEvents:"none",overflow:"hidden"}}>
  <div ref={fallback} className="brand-world-fallback" style={{position:"absolute",left:"71.5%",top:"50%",height:"60%",aspectRatio:"31.5 / 48.5",transform:"translate(-50%,-50%)",opacity:0,visibility:ready?"hidden":"visible"}}>
   <svg viewBox="0 0 31.5 48.5" width="100%" height="100%" style={{position:"absolute",inset:0}}><defs><linearGradient id={"brand-fallback-"+id} x1="0" y1="0" x2="0" y2="1"><stop stopColor="#f2a534"/><stop offset=".48" stopColor="#e6d3b8"/><stop offset="1" stopColor="#248b9a"/></linearGradient></defs><path d="M21.5 0 L21.5 19.5 L31.5 19.5 L31.5 29 L10 48.5 L10 28.5 L0.5 28.5 L0.5 18.5 Z" fill={"url(#brand-fallback-"+id+")"}/><path d="M.5 18.5h9v10h-9zM22 19.5h9.5V29H22z" fill="#e4ece9"/></svg>
  </div>
 </div>
}

