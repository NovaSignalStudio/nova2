import "./concept-pages.css";

export type ConceptPageProps = {
  kind: "ora" | "forma";
  compact?: boolean;
};

/**
 * These are fictional editorial concepts, not client projects.
 * Compact renders only the opening page for the scroll-controlled stage.
 */
export function ConceptPage({ kind, compact = false }: ConceptPageProps) {
  const isOra = kind === "ora";
  return (
    <article
      className={`concept-document concept-document--${kind}${compact ? " concept-document--compact" : ""}`}
      aria-label={isOra ? "ORA — concept di ospitalità" : "FORMA — concept di profumeria"}
    >
      {isOra ? <OraPage compact={compact} /> : <FormaPage compact={compact} />}
    </article>
  );
}

function OraPage({ compact }: { compact: boolean }) {
  return (
    <>
      <section className="concept-document__hero concept-document__ora-hero">
        <img
          className="concept-document__ora-image"
          src="/assets/ora.webp"
          alt="Un'architettura in pietra si apre sul mare al tramonto."
          width="2336"
          height="1744"
          decoding="async"
          loading={compact ? "eager" : "lazy"}
        />
        <div className="concept-document__ora-shade" aria-hidden="true" />
        <header className="concept-document__ora-header">
          <span className="concept-document__ora-wordmark">ORA</span>
          <span className="concept-document__edition">Uno spazio per ritrovarsi</span>
          <span className="concept-document__notice">Concept dimostrativo</span>
        </header>
        <div className="concept-document__ora-title">
          <p className="concept-document__eyebrow">L'arte di abitare il tempo</p>
          <h3>Il tempo,<br /><em>finalmente tuo.</em></h3>
        </div>
        <div className="concept-document__ora-bottom">
          <p>Architettura <span>/</span> Mediterraneo <span>/</span> Ospitalità</p>
          <span aria-hidden="true">01 — ORA</span>
        </div>
      </section>

      {!compact && (
        <>
          <section className="concept-document__ora-story">
            <div className="concept-document__section-index"><span>01 / La visione</span><span>Ospitalità immaginata</span></div>
            <div className="concept-document__ora-story-copy">
              <h4>Ci sono luoghi<br />che fanno spazio.<br /><em>Anche dentro.</em></h4>
              <div className="concept-document__ora-story-body">
                <p>Una soglia tra la pietra e il mare. La luce entra, il paesaggio diventa parte della stanza. E il tempo ritrova il suo passo.</p>
                <p>ORA immagina un'ospitalità fatta di silenzio, materia e orizzonti aperti. Un racconto digitale in cui l'architettura lascia respirare ogni dettaglio.</p>
              </div>
            </div>
          </section>
          <figure className="concept-document__ora-detail">
            <img src="/assets/ora.webp" alt="Dettaglio della luce del tramonto riflessa sul pavimento di pietra." width="2336" height="1744" loading="lazy" decoding="async" />
            <figcaption>La materia custodisce la luce.</figcaption>
          </figure>
          <footer className="concept-document__endnote">
            <span>ORA</span>
            <p>Hotel immaginario. Concept di direzione artistica e sito web realizzato da NovaSignal; non rappresenta una struttura o un cliente reale.</p>
          </footer>
        </>
      )}
    </>
  );
}

function FormaPage({ compact }: { compact: boolean }) {
  return (
    <>
      <section className="concept-document__hero concept-document__forma-hero">
        <div className="concept-document__forma-ambient" aria-hidden="true" />
        <header className="concept-document__forma-header">
          <span className="concept-document__eyebrow">Oggetti di una sensibilità</span>
          <span className="concept-document__notice">Concept dimostrativo</span>
        </header>
        <span className="concept-document__forma-wordmark">FORMA</span>
        <figure className="concept-document__forma-image">
          <img src="/assets/forma.webp" alt="Flacone di profumo in vetro scuro con tappo metallico, attraversato da luce obliqua." width="1792" height="2240" decoding="async" loading={compact ? "eager" : "lazy"} />
        </figure>
        <div className="concept-document__forma-title">
          <p className="concept-document__eyebrow">Profumo. Materia. Identità.</p>
          <h3>Una presenza.<br /><span>Essenziale.</span></h3>
          <p className="concept-document__forma-intro">Ciò che rimane,<br />quando tutto il resto si dissolve.</p>
        </div>
        <div className="concept-document__forma-bottom">
          <span>Studio olfattivo immaginario</span>
          <span aria-hidden="true">F / 01</span>
        </div>
      </section>

      {!compact && (
        <>
          <section className="concept-document__forma-story">
            <div className="concept-document__section-index"><span>01 / L'essenza</span><span>Una ricerca visiva</span></div>
            <h4>Materia.<br /><span>Luce.</span><br />Identità.</h4>
            <div className="concept-document__forma-story-body">
              <p>Il vetro trattiene la luce. Il metallo ne disegna il confine. Una forma semplice, osservata da vicino, rivela un carattere preciso.</p>
              <p>FORMA è un'esplorazione del rapporto tra oggetto e percezione. Un'identità immaginaria per raccontare il profumo attraverso composizione, tattilità e movimento.</p>
            </div>
          </section>
          <footer className="concept-document__endnote">
            <span>FORMA</span>
            <p>Marchio immaginario. Concept di identità e sito web realizzato da NovaSignal; non rappresenta un prodotto in vendita o un cliente reale.</p>
          </footer>
        </>
      )}
    </>
  );
}

