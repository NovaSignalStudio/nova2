import {lazy,Suspense,useEffect,useRef,useState,type FormEvent} from "react";
import {gsap} from "gsap";
import {ScrollTrigger} from "gsap/ScrollTrigger";
import Lenis from "lenis";
import {contact,services,process} from "@/content";
import {ConceptPage} from "./ConceptPages";
import "./directed.css";
const BrandWorld=lazy(()=>import("./BrandWorld"));
const Arrow=()=> <span aria-hidden="true">↗</span>;
type Kind="ora"|"forma";
type Pose={x:number;y:number;scale:number;rx:number;ry:number;rz:number;split:number;opacity:number};
function Navigation(){
 const [open,setOpen]=useState(false);const dialog=useRef<HTMLDialogElement>(null);const trigger=useRef<HTMLButtonElement>(null);
 useEffect(()=>{if(open)dialog.current?.showModal();else dialog.current?.close()},[open]);
 const close=()=>{setOpen(false);trigger.current?.focus()};
 return <><a className="ns-skip" href="#servizi">Vai ai contenuti</a><header className="ns-nav">
 <a className="ns-brand" href="#inizio" aria-label="NovaSignal, inizio"><img src="/assets/brand-mark.svg" alt="" width="23" height="35"/><span>NovaSignal</span></a>
 <nav aria-label="Navigazione principale"><a href="#servizi">Cosa facciamo</a><a href="#concept">Esplorazioni</a><a href="#studio">Il metodo</a></nav>
 <a className="ns-nav-cta" href="#contatti">Parliamo <Arrow/></a>
 <button className="ns-menu-toggle" aria-label="Apri menu" aria-expanded={open} ref={trigger} onClick={()=>setOpen(true)}><span/><span/></button>
 </header><dialog ref={dialog} data-lenis-prevent className="ns-menu" onCancel={close} onClose={()=>setOpen(false)}><div className="ns-menu-head"><span>NovaSignal</span><button onClick={close} aria-label="Chiudi menu">×</button></div><nav aria-label="Menu mobile">{[["servizi","Cosa facciamo"],["concept","Esplorazioni"],["studio","Il metodo"],["contatti","Parliamo"]].map(([id,label])=><a href={"#"+id} key={id} onClick={close}>{label}<Arrow/></a>)}</nav><a className="ns-menu-mail" href={"mailto:"+contact.email}>{contact.email}</a></dialog></>;
}
function Opening(){
 const video=useRef<HTMLVideoElement>(null);
 useEffect(()=>{const el=video.current;if(!el||matchMedia("(prefers-reduced-motion: reduce)").matches)return;const mobile=matchMedia("(max-width:700px)").matches;el.src=mobile?"/assets/brand-film-mobile.mp4":"/assets/brand-film.mp4";el.load()},[]);
 return <section className="ns-opening" id="inizio" aria-labelledby="ns-title"><div className="ns-opening-stage">
 <picture className="ns-opening-poster"><source media="(max-width:700px)" srcSet="/assets/brand-metal-mobile.webp"/><img src="/assets/brand-metal-poster.webp" alt="Il simbolo NovaSignal in metallo arancio, turchese e cromo" fetchPriority="high"/></picture>
 <video className="ns-film" ref={video} muted playsInline preload="auto" aria-hidden="true" onLoadedData={e=>e.currentTarget.classList.add("is-loaded")} onError={e=>e.currentTarget.classList.remove("is-loaded")}/>
 <div className="ns-film-shade"/>
 <div className="ns-opening-copy"><p className="ns-kicker"><i/> Studio digitale indipendente</p><h1 id="ns-title">Da un segno,<br/>nuove <em>possibilità.</em></h1><p className="ns-opening-sub">Siti web, applicazioni e identità.<br/>Diamo forma a ciò che hai in mente.</p><a className="ns-text-link" href="#contatti">Il tuo progetto comincia qui <Arrow/></a></div>
 <div className="ns-macro-copy" aria-hidden="true"><span>01 / Il dettaglio</span><p>Ogni dettaglio.<br/>Una direzione.</p></div>
 <div className="ns-opening-bottom"><span>Design & tecnologia<br/>Un'unica visione.</span><a href="#servizi">Scorri per entrare <span>↓</span></a><span>Italia / Ovunque</span></div>
 <div className="ns-film-progress"><i/></div>
 </div></section>;
}
function Capabilities(){
 const [active,setActive]=useState(0);
 return <section className="ns-services" id="servizi" aria-labelledby="ns-services-title"><div className="ns-services-stage">
 <div className="ns-stage-label"><span>01 — Cosa facciamo</span><span>Il segnale prende forma.</span></div>
 <div className="ns-service-copy"><h2 id="ns-services-title">La tua idea.<br/>In ogni dimensione.</h2><div className="ns-service-list">{services.map((s,i)=><button key={s.title} className={active===i?"is-selected":""} aria-pressed={active===i} aria-controls="service-explanation" onClick={()=>setActive(i)}><span className="ns-row-n">0{i+1}</span><span>{s.title}</span><Arrow/></button>)}</div>
 <div id="service-explanation" className="ns-service-description" aria-live="polite"><p>{services[active].text}</p><a href="#contatti">Parliamo del tuo progetto <Arrow/></a></div></div>
 <p className="ns-object-caption">Una forma riconoscibile.<br/>Infinite possibilità di costruirci intorno.</p>
 </div></section>;
}
function Portal({kind,order,onOpen}:{kind:Kind;order:number;onOpen:(kind:Kind,button:HTMLButtonElement)=>void}){
 const isOra=kind==="ora";
 return <section id={isOra?"concept":"forma"} className={"ns-portal ns-portal-"+kind} aria-labelledby={"portal-title-"+kind}><div className="ns-portal-stage">
 <div className="ns-stage-label"><span>02 — Esplorazioni</span><span>0{order} / 02</span></div>
 <div className="ns-portal-intro"><span className="ns-kicker">Dal segno all'esperienza</span><h2 id={"portal-title-"+kind}>{isOra?<>Si apre<br/>un mondo.</>:<>La forma<br/>del desiderio.</>}</h2><p>{isOra?"Un luogo comincia a raccontarsi. Prima ancora di arrivare.":"Materia, identità e interazione. Un nuovo punto di vista."}</p></div>
 <div className="ns-portal-depth" aria-hidden="true"><i/><i/><i/></div>
 <div className="ns-page-flight"><ConceptPage kind={kind} compact/></div>
 <div className="ns-portal-caption"><span>{isOra?"ORA / Hospitality":"FORMA / Brand & prodotto"}</span><small>Concept di studio · Non commissionato</small></div>
 <button className="ns-portal-open" onClick={e=>onOpen(kind,e.currentTarget)}>Esplora {kind.toUpperCase()} <Arrow/></button>
 </div></section>;
}
function Craft(){
 return <section className="ns-craft" id="studio" aria-labelledby="ns-craft-title"><div className="ns-craft-stage">
 <div className="ns-stage-label"><span>03 — Il metodo</span><span>Ogni parte, al posto giusto.</span></div>
 <div className="ns-craft-copy"><p className="ns-kicker">Strategia. Design. Sviluppo.</p><h2 id="ns-craft-title">La forma segue<br/>un'idea chiara.</h2><div className="ns-process"><div className="ns-process-line"><i/></div>{process.map((p,i)=><article key={p.title}><span>0{i+1}</span><div><h3>{p.title}</h3><p>{p.body}</p></div></article>)}</div></div>
 <p className="ns-craft-note">Dall'intuizione alla messa online.<br/>Un percorso condiviso, un progetto coerente.</p>
 </div></section>;
}
function Contact(){
 const [name,setName]=useState("");const [service,setService]=useState("Sito web");const [idea,setIdea]=useState("");const [draft,setDraft]=useState("");
 function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();setDraft(contact.whatsapp+"?text="+encodeURIComponent("Ciao NovaSignal, sono "+name.trim()+". Vorrei parlare di: "+service+".\n"+idea.trim()))}
 return <section className="ns-contact" id="contatti" aria-labelledby="ns-contact-title"><div className="ns-contact-heading"><p className="ns-kicker">04 — Il prossimo progetto</p><h2 id="ns-contact-title">Facciamo<br/>il prossimo<br/><em>passo.</em><Arrow/></h2></div><div className="ns-contact-details"><p>Hai un'idea, una sfida<br/>o un sito da ripensare?<br/>Cominciamo da una conversazione.</p><a href={"mailto:"+contact.email}>{contact.email}</a><a href="tel:+393206891014">{contact.phone}</a><span>Oppure <a href="tel:+393481848483">{contact.secondary}</a></span></div>
 <form className="ns-brief" onSubmit={submit}><h3>Raccontaci il tuo progetto.</h3><div className="ns-form-pair"><label>Come ti chiami<input name="name" autoComplete="name" placeholder="Il tuo nome" minLength={2} maxLength={80} required value={name} onChange={e=>{setName(e.target.value);setDraft("")}}/></label><label>Cosa hai in mente<select value={service} onChange={e=>{setService(e.target.value);setDraft("")}}>{["Sito web","Web app","App mobile","Brand identity","Ne parliamo insieme"].map(s=><option key={s}>{s}</option>)}</select></label></div><label>La tua idea<textarea placeholder="Da dove partiamo?" rows={2} maxLength={1600} value={idea} onChange={e=>{setIdea(e.target.value);setDraft("")}}/></label><button type="submit">Prepara il messaggio <Arrow/></button><p className="ns-form-help">Prepariamo una bozza WhatsApp. Potrai leggerla e inviarla tu.</p>{draft&&<div className="ns-draft" role="status"><p>La bozza è pronta.</p><a href={draft} target="_blank" rel="noopener noreferrer">Apri WhatsApp <Arrow/></a></div>}</form>
 </section>;
}
function useDirection(manualReduce:boolean){
 useEffect(()=>{
 if(manualReduce){document.body.classList.add("ns-manual-reduce");return()=>document.body.classList.remove("ns-manual-reduce")}
 gsap.registerPlugin(ScrollTrigger);const mm=gsap.matchMedia();
 mm.add("(prefers-reduced-motion: no-preference)",()=>{
 document.body.classList.add("ns-live");
 let mobile=innerWidth<701;const lenis=new Lenis({duration:.82,smoothWheel:true,anchors:true,prevent:n=>!!n.closest("dialog[open]")});
 const video=document.querySelector<HTMLVideoElement>(".ns-film");
 const hero=document.querySelector<HTMLElement>(".ns-opening")!;
 const fallback=document.querySelector<HTMLElement>(".ns-opening-poster")!;
 let targetVideo=0;let previousProgress=-1;let failed=false;
 const error=()=>{failed=true};video?.addEventListener("error",error);
 const poses: Array<{id:string;p:number;v:Partial<Pose>;m?:Partial<Pose>}>= [
 {id:"inizio",p:0,v:{x:0,y:0,scale:1,ry:-.25,split:0,opacity:0}},
 {id:"inizio",p:.85,v:{x:0,y:0,scale:1,ry:-.25,split:0,opacity:0}},
 {id:"inizio",p:1,v:{x:0,y:0,scale:.9,ry:-.25,split:0,opacity:1},m:{scale:.68}},
 {id:"servizi",p:0,v:{x:-.48,y:0,scale:1.2,ry:.65,split:0,opacity:1},m:{x:0,y:.43,scale:.48}},
 {id:"servizi",p:.7,v:{x:-.48,y:0,scale:1.22,ry:-.45,rz:-.08,split:.12},m:{x:0,y:.43,scale:.48}},
 {id:"servizi",p:1,v:{x:0,y:0,scale:.7,ry:0,rz:0,split:.3},m:{scale:.55,y:0}},
 {id:"concept",p:0,v:{x:0,y:0,scale:.7,ry:0,split:.3},m:{scale:.45,y:-.3}},
 {id:"concept",p:.25,v:{x:0,y:0,scale:.95,ry:.1,split:1},m:{scale:.65,y:0}},
 {id:"concept",p:.58,v:{x:-.79,y:-.03,scale:.38,ry:-.65,rz:-.15,split:0},m:{x:-.7,y:.65,scale:.2}},
 {id:"concept",p:1,v:{x:-.72,y:0,scale:.36,ry:-.6,rz:0,split:0},m:{x:-.7,y:.65,scale:.2}},
 {id:"forma",p:0,v:{x:-.55,y:0,scale:.55,ry:-.2,split:0},m:{x:0,y:-.3,scale:.45}},
 {id:"forma",p:.24,v:{x:.1,y:0,scale:.9,ry:-.25,split:.9},m:{x:0,y:0,scale:.65}},
 {id:"forma",p:.6,v:{x:.81,y:0,scale:.38,ry:.6,rz:.12,split:0},m:{x:.75,y:.65,scale:.2}},
 {id:"forma",p:1,v:{x:.65,y:0,scale:.5,ry:.5,rz:0,split:0},m:{x:0,y:.35,scale:.5}},
 {id:"studio",p:0,v:{x:.53,y:0,scale:1.22,ry:-.3,rz:.03,split:.1},m:{x:.69,y:.43,scale:.29}},
 {id:"studio",p:.55,v:{x:.53,y:0,scale:1.3,ry:.5,split:.65},m:{x:.69,y:.43,scale:.29}},
 {id:"studio",p:1,v:{x:.64,y:.2,scale:.7,ry:0,split:0},m:{x:.65,y:.6,scale:.25}},
 {id:"contatti",p:0,v:{x:.73,y:.55,scale:.3,ry:-.35,split:0},m:{x:.75,y:.62,scale:.23}},
 {id:"contatti",p:1,v:{x:.73,y:.55,scale:.25,ry:-.35,split:0,opacity:.25},m:{scale:.18}}
 ];
 type Knot={at:number;v:Pose};let knots:Knot[]=[];
 const measure=()=>{mobile=innerWidth<701;let last:Pose={x:0,y:0,scale:1,rx:.08,ry:0,rz:0,split:0,opacity:0};knots=poses.map(k=>{const e=document.getElementById(k.id)!;last={...last,...k.v,...(mobile?k.m:{})};return{at:e.getBoundingClientRect().top+scrollY+k.p*Math.max(1,e.offsetHeight-innerHeight),v:{...last}}}).sort((a,b)=>a.at-b.at)};
 const render=()=>{
  const y=window.scrollY;let a=knots[0],b=knots[knots.length-1];if(!a)return;
  if(y>=b.at)a=b;else for(let i=1;i<knots.length;i++){if(y<=knots[i].at){a=knots[i-1];b=knots[i];break}}
  let t=Math.min(1,Math.max(0,(y-a.at)/Math.max(1,b.at-a.at)));t=t*t*(3-2*t);const pose={} as Pose;
  for(const key of Object.keys(a.v) as (keyof Pose)[])pose[key]=a.v[key]+(b.v[key]-a.v[key])*t;
  window.dispatchEvent(new CustomEvent("nova:pose",{detail:pose}));
  const p=Math.max(0,Math.min(1,-hero.getBoundingClientRect().top/(hero.offsetHeight-innerHeight)));
  if(video&&Number.isFinite(video.duration))targetVideo=p*video.duration*.997;
  if(Math.abs(p-previousProgress)>.00005){previousProgress=p;if(failed)fallback.style.transform="scale("+(1+p*.35)+")";}
  if(video?.readyState&&video.readyState>=2&&!video.seeking&&Math.abs(video.currentTime-targetVideo)>.045)video.currentTime=targetVideo;
 };
 lenis.on("scroll",ScrollTrigger.update);const ticker=(t:number)=>{lenis.raf(t*1000);render()};gsap.ticker.add(ticker);
 const ctx=gsap.context(()=>{
 const opening=gsap.timeline({scrollTrigger:{trigger:hero,start:"top top",end:"bottom bottom",scrub:true}});
 opening.to(".ns-opening-copy",{yPercent:-35,autoAlpha:0,duration:.18},.09)
 .fromTo(".ns-macro-copy",{autoAlpha:0,y:45},{autoAlpha:1,y:0,duration:.15},.3)
 .to(".ns-macro-copy",{autoAlpha:0,y:-40,duration:.12},.57)
 .to(".ns-opening-bottom",{autoAlpha:0,duration:.1},.08)
 .to(".ns-opening-stage",{opacity:0,duration:.11},.89)
 .fromTo(".ns-film-progress i",{scaleX:0},{scaleX:1,duration:1,ease:"none"},0);
 gsap.fromTo(".ns-service-copy",{y:mobile?25:75},{y:0,scrollTrigger:{trigger:"#servizi",start:"top bottom",end:"top top",scrub:true}});
 gsap.to(".ns-service-copy",{autoAlpha:0,y:-35,scrollTrigger:{trigger:"#servizi",start:"top -95%",end:"bottom bottom",scrub:true}});
 gsap.utils.toArray<HTMLElement>(".ns-portal").forEach((section,i)=>{
 const q=gsap.utils.selector(section);const tl=gsap.timeline({scrollTrigger:{trigger:section,start:"top top",end:"bottom bottom",scrub:true}});
 tl.to(q(".ns-portal-intro"),{autoAlpha:0,y:-65,duration:.19},.05)
 .fromTo(q(".ns-page-flight"),{autoAlpha:0,scale:.075,z:-850,rotateX:12,rotateY:i?-34:34,rotateZ:i?8:-8,xPercent:i?18:-18},{autoAlpha:1,scale:1,z:0,rotateX:0,rotateY:0,rotateZ:0,xPercent:0,duration:.46,ease:"power2.inOut"},.16)
 .fromTo(q(".ns-portal-depth"),{autoAlpha:0,scale:.2,rotateY:i?-30:30},{autoAlpha:1,scale:1,rotateY:0,duration:.4},.1)
 .to(q(".ns-portal-depth"),{autoAlpha:0,scale:1.35,duration:.2},.5)
 .fromTo(q(".ns-portal-caption, .ns-portal-open"),{autoAlpha:1,y:20},{autoAlpha:1,y:0,duration:.14},.53)
 .to(q(".ns-page-flight"),{scale:1.025,yPercent:-2,duration:.25,ease:"none"},.7);
 });
 gsap.fromTo(".ns-process-line i",{scaleY:0},{scaleY:1,ease:"none",scrollTrigger:{trigger:"#studio",start:"top top",end:"bottom bottom",scrub:true}});
 gsap.utils.toArray<HTMLElement>(".ns-process article").forEach((item,i)=>gsap.fromTo(item,{opacity:.65,x:12},{opacity:1,x:0,scrollTrigger:{trigger:"#studio",start:()=> "top -"+Math.round(i*18)+"%",end:()=> "top -"+Math.round(i*18+20)+"%",scrub:true}}));
 gsap.fromTo(".ns-contact-heading",{y:90},{y:0,scrollTrigger:{trigger:"#contatti",start:"top bottom",end:"top 20%",scrub:true}});
 gsap.fromTo(".ns-footer-word",{yPercent:35},{yPercent:0,scrollTrigger:{trigger:".ns-footer",start:"top bottom",end:"bottom bottom",scrub:true}});
 });
 measure();ScrollTrigger.addEventListener("refresh",measure);window.addEventListener("resize",measure);document.fonts.ready.then(()=>ScrollTrigger.refresh());render();
 return()=>{ctx.revert();gsap.ticker.remove(ticker);ScrollTrigger.removeEventListener("refresh",measure);window.removeEventListener("resize",measure);video?.removeEventListener("error",error);lenis.destroy();document.body.classList.remove("ns-live")};
 });return()=>mm.revert()
 },[manualReduce]);
}
export default function DirectedSite(){
 const [manualReduce,setManualReduce]=useState(false);useDirection(manualReduce);const [selected,setSelected]=useState<Kind|null>(null);const dialog=useRef<HTMLDialogElement>(null);const last=useRef<HTMLButtonElement|null>(null);
 useEffect(()=>{if(selected)dialog.current?.showModal();else dialog.current?.close()},[selected]);
 const close=()=>{setSelected(null);last.current?.focus()};
 const open=(kind:Kind,button:HTMLButtonElement)=>{last.current=button;setSelected(kind)};
 return <div className="ns-site"><div className="ns-world" aria-hidden="true"><div className="ns-world-light"/><Suspense fallback={null}><BrandWorld/></Suspense></div><Navigation/><main><Opening/><Capabilities/><Portal kind="ora" order={1} onOpen={open}/><Portal kind="forma" order={2} onOpen={open}/><Craft/><Contact/></main><footer className="ns-footer"><a className="ns-footer-word" href="#inizio">NovaSignal</a><div><span>Studio digitale italiano.</span><a href="https://novasignal.it/privacy/" target="_blank" rel="noopener noreferrer">Privacy e cookie ↗</a><span>© 2026 NovaSignal</span><button className="ns-motion-toggle" aria-pressed={manualReduce} onClick={()=>setManualReduce(v=>!v)}>{manualReduce?"Riattiva movimento":"Riduci movimento"}</button><a href="#inizio">Torna su ↑</a></div></footer><dialog ref={dialog} className="ns-concept-dialog" data-lenis-prevent onCancel={close} onClose={()=>setSelected(null)}><button className="ns-dialog-close" onClick={close} aria-label="Chiudi concept">Chiudi <span>×</span></button>{selected&&<ConceptPage kind={selected}/>}<div className="ns-dialog-foot"><span>Un'esplorazione di NovaSignal.</span><a href="#contatti" onClick={close}>Una direzione per il tuo progetto <Arrow/></a></div></dialog></div>;
}
