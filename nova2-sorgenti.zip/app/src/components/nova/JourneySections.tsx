import {lazy,Suspense,useEffect,useRef,useState} from "react";
import {gsap} from "gsap";
import {ScrollTrigger} from "gsap/ScrollTrigger";
import {services,projects,process} from "@/content";
import "./journey.css";
const SignalScene=lazy(()=>import("./SignalScene"));
const Arrow=()=> <span aria-hidden="true">↗</span>;
function jump(id:string,index:number,count:number){
 const section=document.getElementById(id);if(!section)return;
 if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){
  section.querySelectorAll<HTMLElement>("article")[index]?.scrollIntoView({block:"center"});return;
 }
 const top=section.getBoundingClientRect().top+window.scrollY;
 window.dispatchEvent(new CustomEvent("nova:jump",{detail:top+(section.offsetHeight-window.innerHeight)*(index/(count-1))}));
}
function JourneyObject(){
 const [show,setShow]=useState(false);const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{const io=new IntersectionObserver(e=>{if(e[0].isIntersecting){setShow(true);io.disconnect()}},{rootMargin:"300px"});if(ref.current)io.observe(ref.current);return()=>io.disconnect()},[]);
 return <div className="service-object" ref={ref}>{show?<Suspense fallback={<img src="/assets/signal-still.webp" alt="" />}><SignalScene material="metal" exploded={false} rotation={0} mode="journey"/></Suspense>:<img src="/assets/signal-still.webp" alt="" loading="lazy"/>}</div>
}
export function Manifesto(){
 return <section className="signal-passage" aria-label="La nostra visione"><div className="passage-stage">
  <img className="passage-image" src="/assets/macro.webp" alt="" loading="lazy"/>
  <div className="passage-window" aria-hidden="true"/>
  <div className="passage-copy"><p className="eyebrow">Da un segnale, una possibilità.</p><p className="passage-statement">La tua idea.<br/>Una nuova<br/><em>dimensione.</em></p><p className="passage-note">Strategia, design e tecnologia.<br/>Un'unica visione.</p></div>
 </div></section>
}
export function Services(){
 return <section id="servizi" className="service-journey" aria-labelledby="journey-services-title"><div className="service-stage">
  <div className="journey-topline"><h2 id="journey-services-title">Diamo forma alle idee.</h2><span>01 — Cosa realizziamo</span></div>
  <JourneyObject/>
  <div className="service-copies">{services.map((s,i)=><article className="service-scene" key={s.title}>
   <span className="scene-index">0{i+1} / 04</span><h3>{s.title}</h3><p className="service-lead">{s.lead}</p><p className="service-body">{s.text}</p><p className="service-tags">{s.tags}</p><a className="scene-link" href="#contatti">Parliamo del tuo progetto <Arrow/></a>
  </article>)}</div>
  <nav className="journey-tabs" aria-label="Scegli un servizio">{services.map((s,i)=><button key={s.title} onClick={()=>jump("servizi",i,4)}><span>0{i+1}</span>{s.title}<i/></button>)}</nav>
  <div className="service-orbit" aria-hidden="true"><span>NovaSignal — Digital experiences —</span></div>
 </div></section>
}
export function Projects(){
 const [selected,setSelected]=useState<number|null>(null);const dialog=useRef<HTMLDialogElement>(null);const last=useRef<HTMLButtonElement|null>(null);
 useEffect(()=>{if(selected!==null)dialog.current?.showModal();else dialog.current?.close()},[selected]);
 const close=()=>{setSelected(null);last.current?.focus()};const p=selected===null?null:projects[selected];
 return <section id="concept" className="concept-journey" aria-label="Concept di studio">
 {projects.map((p,i)=><article className={"concept-scene concept-"+p.id} key={p.id}><div className="concept-stage">
  <div className="concept-photo"><img src={p.image} alt={p.alt} loading="lazy"/></div>
  <div className="concept-vignette"/>
  <div className="concept-topline"><span>02 — Concept di studio</span><span>0{i+1} / 02</span></div>
  <div className="concept-intro"><p>Possibilità,<br/>da esplorare.</p><span>Esplorazioni originali.<br/>Progetti dimostrativi.</span></div>
  <div className="concept-caption-live"><p>{p.category}</p><h2>{p.name}</h2><span>{p.statement}</span></div>
  <button className="concept-enter" onClick={e=>{last.current=e.currentTarget;setSelected(i)}} aria-label={"Esplora il concept "+p.name}>Entra nel concept <Arrow/></button>
  <p className="concept-disclaimer">Concept dimostrativo · Non commissionato</p>
 </div></article>)}
 <dialog data-lenis-prevent ref={dialog} className="project-dialog" onCancel={close} onClose={()=>setSelected(null)}>
 {p&&<><button className="dialog-close" onClick={close} aria-label="Chiudi concept">Chiudi <span>×</span></button><div className={"concept-preview "+p.tone}><img src={p.image} alt={p.alt}/><span className="concept-preview-brand">{p.name}</span><h2>{p.statement}</h2></div><div className="concept-story"><p className="eyebrow">Concept di studio</p><h3>{p.title}</h3><p>{p.body}</p><p className="concept-scope">{p.detail}</p><a href="#contatti" onClick={close}>Parliamo di una direzione per te <Arrow/></a></div></>}
 </dialog></section>
}
export function Method(){
 return <section className="method-journey" id="metodo" aria-labelledby="journey-method-title"><div className="method-stage">
  <img className="method-image" src="/assets/macro.webp" alt="" loading="lazy"/><div className="method-shade"/>
  <div className="journey-topline"><h2 id="journey-method-title">Una visione. Un percorso chiaro.</h2><span>04 — Il metodo</span></div>
  <div className="method-copies">{process.map((p,i)=><article className="method-scene" key={p.title}><span className="method-giant" aria-hidden="true">0{i+1}</span><div className="method-scene-copy"><span className="scene-index">0{i+1} / 04</span><h3>{p.title}</h3><p>{p.body}</p></div></article>)}</div>
  <nav className="journey-tabs" aria-label="Le fasi del progetto">{process.map((p,i)=><button key={p.title} onClick={()=>jump("metodo",i,4)}><span>0{i+1}</span>{p.title}<i/></button>)}</nav>
 </div></section>
}
export function useJourneyMotion(){
 useEffect(()=>{
  gsap.registerPlugin(ScrollTrigger);const mm=gsap.matchMedia();
  mm.add("(prefers-reduced-motion: no-preference)",()=>{
   document.body.classList.add("motion-enabled");
   const ctx=gsap.context(()=>{
    const passage=gsap.timeline({scrollTrigger:{trigger:".signal-passage",start:"top bottom",end:"bottom top",scrub:true}});
    passage.fromTo(".passage-image",{scale:1.5,xPercent:12},{scale:1,xPercent:-8,ease:"none"},0)
      .fromTo(".passage-window",{scale:.65,rotate:25},{scale:2.5,rotate:-15,ease:"none"},0)
      .fromTo(".passage-copy",{yPercent:18},{yPercent:-16,ease:"none"},0);
    for(const [root,selector] of [["#servizi",".service-scene"],["#metodo",".method-scene"]]){
     const panels=gsap.utils.toArray<HTMLElement>(root+" "+selector);
     const tabs=gsap.utils.toArray<HTMLButtonElement>(root+" .journey-tabs button");
     gsap.set(panels.slice(1),{autoAlpha:0,yPercent:16,filter:"blur(8px)"});
     const tl=gsap.timeline({scrollTrigger:{trigger:root,start:"top top",end:"bottom bottom",scrub:true,onUpdate:self=>{
      const n=Math.min(3,Math.floor(self.progress*4));tabs.forEach((t,i)=>{t.setAttribute("aria-current",i===n?"step":"false");t.style.setProperty("--tab-progress",String(i<n?1:i>n?0:(self.progress*4-n)))})
     }}});
     panels.forEach((panel,i)=>{
      if(i>0)tl.to(panel,{autoAlpha:1,yPercent:0,filter:"blur(0px)",duration:.07,ease:"power1.out"},i*.25-.04);
      if(i<3)tl.to(panel,{autoAlpha:0,yPercent:-18,filter:"blur(7px)",duration:.06,ease:"power1.in"},(i+1)*.25-.07);
     });tl.to({}, {duration:.22},.78);
    }
    gsap.utils.toArray<HTMLElement>(".concept-scene").forEach(scene=>{
     const q=gsap.utils.selector(scene);const tl=gsap.timeline({scrollTrigger:{trigger:scene,start:"top top",end:"bottom bottom",scrub:true}});
     tl.fromTo(q(".concept-photo"),{clipPath:"inset(12% 15% 12% 15%)"},{clipPath:"inset(0% 0% 0% 0%)",duration:.36,ease:"power2.inOut"},0)
      .fromTo(q(".concept-photo img"),{scale:1.5,yPercent:-7},{scale:1.03,yPercent:4,duration:1,ease:"none"},0)
      .fromTo(q(".concept-intro"),{autoAlpha:1,y:0},{autoAlpha:0,y:-90,duration:.23},.04)
      .fromTo(q(".concept-caption-live"),{autoAlpha:0,yPercent:60},{autoAlpha:1,yPercent:0,duration:.23},.22)
      .fromTo(q(".concept-enter"),{autoAlpha:1,y:25},{autoAlpha:1,y:0,duration:.16},.4)
      .to(q(".concept-caption-live"),{yPercent:-12,duration:.35,ease:"none"},.65);
    });
    gsap.fromTo(".method-image",{scale:1.55,xPercent:12,rotate:-10},{scale:1.02,xPercent:-10,rotate:5,ease:"none",scrollTrigger:{trigger:"#metodo",start:"top top",end:"bottom bottom",scrub:true}});
    gsap.fromTo(".service-orbit",{rotate:-25},{rotate:65,ease:"none",scrollTrigger:{trigger:"#servizi",start:"top top",end:"bottom bottom",scrub:true}});
    gsap.fromTo(".lab-copy",{y:window.innerWidth<700?15:70},{y:window.innerWidth<700?-10:-35,ease:"none",scrollTrigger:{trigger:"#studio",start:"top top",end:"bottom bottom",scrub:true}});
    gsap.fromTo(".contact-top",{y:100,scale:.86,transformOrigin:"left center"},{y:0,scale:1,ease:"power2.out",scrollTrigger:{trigger:"#contatti",start:"top 90%",end:"top 20%",scrub:true}});
    gsap.fromTo(".footer-brand",{yPercent:45,letterSpacing:"-.12em"},{yPercent:0,letterSpacing:"-.075em",scrollTrigger:{trigger:".site-footer",start:"top bottom",end:"bottom bottom",scrub:true}});
   });
   document.fonts.ready.then(()=>ScrollTrigger.refresh());
   return()=>{ctx.revert();document.body.classList.remove("motion-enabled")};
  });return()=>mm.revert()
 },[])
}
