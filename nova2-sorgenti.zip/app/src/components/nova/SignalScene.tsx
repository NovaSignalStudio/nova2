import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";

type Props = { material: "metal" | "glass"; exploded: boolean; rotation: number; mode?: "lab" | "journey" };
export default function SignalScene({material, exploded, rotation,mode="lab"}: Props) {
 const host = useRef<HTMLDivElement>(null);
 const state = useRef({material,exploded,rotation});
 const [ready,setReady] = useState(false);
 useEffect(()=>{state.current={material,exploded,rotation}},[material,exploded,rotation]);
 useEffect(()=>{
  const el=host.current;if(!el)return;
  let stopped=false,frame=0,visible=false,last=0;
  let renderer:THREE.WebGLRenderer;
  try { renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:"low-power"}); }
  catch { return; }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.6));
  renderer.setClearColor(0x24131b,0);renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.55;
  el.appendChild(renderer.domElement);
  renderer.domElement.setAttribute("aria-label","Scultura tridimensionale NovaSignal");renderer.domElement.setAttribute("role","img");
  const scene=new THREE.Scene();
  const camera=new THREE.PerspectiveCamera(34,1,0.1,60);camera.position.set(0,0.1,8.2);
  const pmrem=new THREE.PMREMGenerator(renderer);const room=new RoomEnvironment();
  const env=pmrem.fromScene(room,0.04);scene.environment=env.texture;room.dispose();pmrem.dispose();
  const silver=new THREE.MeshPhysicalMaterial({color:0xe2d9dc,metalness:1,roughness:0.19,clearcoat:0.8,clearcoatRoughness:0.18,envMapIntensity:1.7});
  const glass=new THREE.MeshPhysicalMaterial({color:0xe8b0bf,metalness:0.12,roughness:0.1,transmission:0.88,thickness:0.45,ior:1.5,transparent:true,opacity:0.95,envMapIntensity:1.5});
  const insert=new THREE.MeshPhysicalMaterial({color:0xb52a51,metalness:0.5,roughness:0.2,clearcoat:1,envMapIntensity:2.5});
  const dark=new THREE.MeshStandardMaterial({color:0x321b26,metalness:0.8,roughness:0.35});
  const group=new THREE.Group();scene.add(group);
  const geometries:THREE.BufferGeometry[]=[];
  const box=(w:number,h:number,d:number,r=0.055)=>{const g=new RoundedBoxGeometry(w,h,d,4,r);geometries.push(g);return g};
  const barGeometry=box(0.6,2.8,0.58);
  const diagonalGeometry=box(0.6,3.15,0.58);
  const parts:THREE.Group[]=[];
  const positions=[new THREE.Vector3(-0.94,0,0),new THREE.Vector3(0,0,0),new THREE.Vector3(0.94,0,0)];
  positions.forEach((position,i)=>{
    const part=new THREE.Group();part.position.copy(position);
    const mesh=new THREE.Mesh(i===1?diagonalGeometry:barGeometry,silver);mesh.name="Signal bar "+i;part.add(mesh);
    const groove=new THREE.Mesh(box(0.055,i===1?2.94:2.58,0.035,0.012),insert);groove.position.set(0.19,0,0.305);part.add(groove);
    const end=new THREE.Mesh(box(0.44,0.06,0.45,0.015),dark);end.position.y=(i===1?1.57:1.4)-0.05;part.add(end);
    if(i===1)part.rotation.z=0.62;
    group.add(part);parts.push(part);
  });
  const glassLayers:THREE.Mesh[]=[];
  positions.forEach((p,i)=>{
   const m=new THREE.Mesh(box(0.68,2.95,0.07,0.025),glass);m.position.copy(p);m.position.z=-0.4;if(i===1)m.rotation.z=0.62;group.add(m);glassLayers.push(m)
  });

  const artwork=new THREE.TextureLoader().load("/assets/macro.webp");artwork.colorSpace=THREE.SRGBColorSpace;artwork.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());
  const artworkMaterial=new THREE.MeshStandardMaterial({map:artwork,roughness:.32,metalness:.12});
  const devices=new THREE.Group();scene.add(devices);const deviceFrames:THREE.Group[]=[];
  const screen=new THREE.MeshPhysicalMaterial({color:0x160c13,metalness:.65,roughness:.26,clearcoat:1,envMapIntensity:1.3});
  const ui=new THREE.MeshStandardMaterial({color:0x682b42,metalness:.5,roughness:.3});
  const glow=new THREE.MeshStandardMaterial({color:0xdf667c,emissive:0x9e2049,emissiveIntensity:.45,metalness:.35,roughness:.25});
  for(let i=0;i<3;i++){
   const frameGroup=new THREE.Group();
   frameGroup.add(new THREE.Mesh(box(3.7,2.5,.18,.08),silver));
   const face=new THREE.Mesh(box(3.51,2.31,.06,.04),screen);face.position.z=.12;frameGroup.add(face);
   const header=new THREE.Mesh(box(3.2,.025,.015,.009),insert);header.position.set(0,.87,.16);frameGroup.add(header);
   for(let k=0;k<3;k++){const dot=new THREE.Mesh(box(.045,.045,.02,.015),glow);dot.position.set(-1.52+k*.12,1.03,.17);frameGroup.add(dot)}
   const imagePanel=new THREE.Mesh(box(1.1,1.34,.06,.025),artworkMaterial);imagePanel.position.set(.93,-.08,.19);frameGroup.add(imagePanel);
   for(let k=0;k<4;k++){const line=new THREE.Mesh(box(k===3?.65:1.33,k===0?.09:.025,.025,.009),k===0?silver:ui);line.position.set(-.68,.45-k*.29,.18);frameGroup.add(line)}
   devices.add(frameGroup);deviceFrames.push(frameGroup)
  }
  devices.visible=mode==="journey";
  const poses=[
   {p:0,n:1,d:.001,x:1,y:1,spread:0,turn:-.4,explode:0},
   {p:.20,n:.001,d:1,x:1,y:1,spread:0,turn:-.45,explode:1},
   {p:.44,n:.001,d:.93,x:1,y:1,spread:1,turn:.2,explode:1},
   {p:.68,n:.001,d:.9,x:.47,y:1.30,spread:.8,turn:-.25,explode:1},
   {p:.88,n:1,d:.001,x:1,y:1,spread:0,turn:.65,explode:.5},
   {p:1,n:1.05,d:.001,x:1,y:1,spread:0,turn:-.3,explode:0}
  ];
  const pose=(p:number)=>{
   let a=poses[0],b=poses[1];for(let i=1;i<poses.length;i++){if(p<=poses[i].p){a=poses[i-1];b=poses[i];break}}
   const t=THREE.MathUtils.smoothstep(p,a.p,b.p);
   const mix=(key:"n"|"d"|"x"|"y"|"spread"|"turn"|"explode")=>THREE.MathUtils.lerp(a[key],b[key],t);
   return {n:mix("n"),d:mix("d"),x:mix("x"),y:mix("y"),spread:mix("spread"),turn:mix("turn"),explode:mix("explode")};
  };
  const ambient=new THREE.AmbientLight(0xffffff,1.3);scene.add(ambient);
  const key=new THREE.DirectionalLight(0xffffff,5);key.position.set(-3,5,5);scene.add(key);
  const rim=new THREE.DirectionalLight(0xf1b1c0,4);rim.position.set(4,1,-3);scene.add(rim);
  const fill=new THREE.DirectionalLight(0xffffff,2);fill.position.set(0,-4,2);scene.add(fill);
  let pointerX=0,pointerY=0,angle=0,exp=0,scroll=0;
  const reduced=window.matchMedia("(prefers-reduced-motion: reduce)");
  const resize=()=>{const w=el.clientWidth,h=el.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.position.z=w/h<0.9?10:8.2;camera.updateProjectionMatrix()};
  const ro=new ResizeObserver(resize);ro.observe(el);resize();
  const pointer=(e:PointerEvent)=>{if(e.pointerType==="touch")return;const b=el.getBoundingClientRect();pointerX=(e.clientX-b.left)/b.width-.5;pointerY=(e.clientY-b.top)/b.height-.5};
  const leave=()=>{pointerX=0;pointerY=0};
  const readScroll=()=>{const section=el.closest(mode==="journey"?".service-journey":".signal-lab") as HTMLElement|null;if(!section)return;const rect=section.getBoundingClientRect();scroll=THREE.MathUtils.clamp(-rect.top/Math.max(1,section.offsetHeight-window.innerHeight),0,1)};
  const tick=(time:number)=>{
   if(stopped)return;frame=requestAnimationFrame(tick);if(!visible||document.hidden)return;
   const dt=Math.min((time-last)/1000,.05);last=time;const k=1-Math.exp(-6*dt);
   const p=pose(scroll);const journey=mode==="journey"&&!reduced.matches;
   const autoExplode=journey?p.explode:reduced.matches?0:Math.sin(scroll*Math.PI)*.72;
   angle+=(state.current.rotation*Math.PI/180-angle)*k;exp+=((state.current.exploded?1:autoExplode)-exp)*k;
   const targetY=angle+(reduced.matches?-.3:(journey?p.turn:(scroll-.5)*2.1-.3)+pointerX*.35);
   group.rotation.y+=(targetY-group.rotation.y)*k;group.rotation.x+=((reduced.matches?.03:pointerY*.16+.06)-group.rotation.x)*k;
   group.rotation.z=journey?Math.sin(scroll*Math.PI*2)*.07:-.04;
   const targetScale=journey?p.n:1;group.scale.lerp(new THREE.Vector3(targetScale,targetScale,targetScale),k);group.visible=group.scale.x>.015;
   devices.visible=journey&&p.d>.015;devices.scale.lerp(new THREE.Vector3(p.d,p.d,p.d),k);devices.rotation.y+=(p.turn+pointerX*.2-devices.rotation.y)*k;devices.rotation.x+=(pointerY*.12-devices.rotation.x)*k;
   deviceFrames.forEach((f,i)=>{f.visible=i===1||p.spread>.02;f.scale.set(p.x,p.y,1);f.position.set((i-1)*p.spread*1.25,(i-1)*p.spread*.28,-Math.abs(i-1)*p.spread*1.3);f.rotation.y=(i-1)*p.spread*.22});
   key.position.x=-3+Math.sin(scroll*Math.PI*2)*2;
   const targetZ=camera.aspect<.9?(journey?9.8:9.3):(journey?8.6:8.2-Math.sin(scroll*Math.PI)*1.2);camera.position.z+=(targetZ-camera.position.z)*k;
   parts.forEach((part,i)=>{part.position.copy(positions[i]);part.position.x+=(i-1)*exp*.52;part.position.z+=(i===1?.65:-.1)*exp;const mesh=part.children[0] as THREE.Mesh;mesh.material=state.current.material==="glass"?glass:silver});
   glassLayers.forEach((m,i)=>{m.position.z=-.4-exp*(.3+i*.13);m.position.x=positions[i].x+(i-1)*exp*.52});
   renderer.render(scene,camera);
  };
  const io=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;readScroll()},{rootMargin:"150px"});io.observe(el);
  const lost=(e:Event)=>{e.preventDefault();setReady(false);visible=false};
  renderer.domElement.addEventListener("webglcontextlost",lost);
  el.addEventListener("pointermove",pointer);el.addEventListener("pointerleave",leave);window.addEventListener("scroll",readScroll,{passive:true});readScroll();
  setReady(true);frame=requestAnimationFrame(tick);
  return()=>{stopped=true;cancelAnimationFrame(frame);io.disconnect();ro.disconnect();el.removeEventListener("pointermove",pointer);el.removeEventListener("pointerleave",leave);window.removeEventListener("scroll",readScroll);renderer.domElement.removeEventListener("webglcontextlost",lost);geometries.forEach(g=>g.dispose());[silver,glass,insert,dark,screen,ui,glow,artworkMaterial].forEach(m=>m.dispose());artwork.dispose();env.dispose();renderer.dispose();renderer.domElement.remove()};
 },[mode]);
 return <div className={"signal-render "+(ready?"is-ready":"")} ref={host}><img className="signal-fallback" src="/assets/signal-still.webp" alt="Scultura metallica NovaSignal" loading="lazy"/></div>;
}
