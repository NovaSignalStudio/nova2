export const contact = {
  email: "studio@novasignal.it",
  phone: "+39 320 689 1014",
  whatsapp: "https://wa.me/393206891014",
  secondary: "+39 348 184 8483",
};
export const services = [
 {title:"Siti web", lead:"La tua presenza, con una personalità.", text:"Siti corporate, portfolio ed e-commerce. Mettiamo insieme contenuti chiari, design su misura e un percorso semplice verso il contatto.", tags:"Strategia / Design / Sviluppo", icon:"web"},
 {title:"Web app", lead:"Un'idea che diventa uno strumento.", text:"Portali, dashboard e applicazioni SaaS. Progettiamo le interfacce e costruiamo le funzioni che fanno lavorare il tuo prodotto.", tags:"UX / Frontend / Backend", icon:"app"},
 {title:"App mobile", lead:"Il tuo servizio, a portata di mano.", text:"Esperienze pensate per iOS, Android e web. Dalla prima schermata alle interazioni quotidiane, ogni gesto ha un compito.", tags:"Interfaccia / Prodotto / Sviluppo", icon:"mobile"},
 {title:"Brand identity", lead:"Riconoscibile, prima ancora di leggere.", text:"Naming, logo e identità visiva. Un linguaggio coerente che tiene insieme ciò che dici, ciò che mostri e ciò che costruisci.", tags:"Naming / Identità / Direzione artistica", icon:"brand"}
];
export const projects = [
 {id:"ora", name:"ORA", category:"Hospitality / Digital experience", image:"/assets/ora.webp", alt:"Architettura in pietra affacciata sul mare al tramonto", title:"Un luogo da sentire, prima di arrivare.", body:"Un concept per l'ospitalità: architettura, ritmo lento e immagini a tutta pagina. Il percorso accompagna dalla scoperta degli spazi alla richiesta di soggiorno.", detail:"Direzione artistica, esperienza web, racconto degli spazi.", statement:"Abitare il tempo.", tone:"ora"},
 {id:"forma", name:"FORMA", category:"Design / Brand experience", image:"/assets/forma.webp", alt:"Oggetto di profumeria in vetro fumé con tappo metallico", title:"Il dettaglio diventa desiderio.", body:"Un concept di brand e prodotto: materiali, luce e composizione guidano la scoperta. Un'immagine editoriale incontra interazioni precise e informazioni essenziali.", detail:"Identità visiva, art direction, presentazione di prodotto.", statement:"L'essenza della forma.", tone:"forma"}
];
export const process = [
 {title:"Ascoltiamo.", body:"Partiamo dalla tua attività, dal pubblico e dall'azione che vuoi ottenere."},
 {title:"Progettiamo.", body:"Mettiamo a fuoco struttura, identità e una direzione visiva concreta."},
 {title:"Costruiamo.", body:"Design e sviluppo procedono insieme. Verifichiamo le esperienze su desktop e telefono."},
 {title:"Lanciamo.", body:"Prepariamo la messa online e ti accompagniamo nell'uso del tuo nuovo progetto."}
];