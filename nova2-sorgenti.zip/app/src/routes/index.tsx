import { createFileRoute } from "@tanstack/react-router";
import NovaSite from "@/components/nova/NovaSite";
export const Route=createFileRoute("/")({component:NovaSite});
