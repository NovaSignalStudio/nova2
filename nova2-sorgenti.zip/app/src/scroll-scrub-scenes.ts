import type { ScrollScrubScene, ScrollScrubTheme } from "@/components/scroll-scrub/scroll-scrub";
export const scrollScrubTheme: ScrollScrubTheme = {accent:"#df667c",background:"#24131b",ink:"#f2efef",muted:"#c6b5bc"};
export const scrollScrubScenes: ScrollScrubScene[] = [{
 id:"segnale",label:"Il segnale",title:"La tua prossima dimensione digitale.",
 body:"Siti, applicazioni e identità. Progettati per lasciare il segno.",
 clip:"/assets/world/signal.mp4",poster:"/assets/world/signal-poster.jpg",
 mobileClip:"/assets/world/signal-mobile.mp4",mobilePoster:"/assets/world/signal-mobile-poster.jpg",
 scroll:3.6,linger:0.22,objectPosition:"center center",mobileObjectPosition:"center center"
}];
export const scrollThemeColor = "#24131b";
