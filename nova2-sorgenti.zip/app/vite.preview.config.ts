import {defineConfig} from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import {fileURLToPath} from "node:url";
export default defineConfig({
 root:"preview",publicDir:"../public",
 resolve:{alias:{"@":fileURLToPath(new URL("./src",import.meta.url))}},
 plugins:[react(),tailwindcss()],
 build:{outDir:"../dist-preview",emptyOutDir:true},
});
